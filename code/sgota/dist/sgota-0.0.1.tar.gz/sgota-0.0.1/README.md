This project is intended to take code that is uploaded to Github and install new updates based off of commit dates. This program will replace an existing program with the new version.
